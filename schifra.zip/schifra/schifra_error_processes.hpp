/*
(**************************************************************************)
(*                                                                        *)
(*                                Schifra                                 *)
(*                Reed-Solomon Error Correcting Code Library              *)
(*                                                                        *)
(* Release Version 0.0.1                                                  *)
(* http://www.schifra.com                                                 *)
(* Copyright (c) 2000-2007 Arash Partow, All Rights Reserved.             *)
(*                                                                        *)
(* The Schifra Reed-Solomon error correcting code library and all its     *)
(* components are supplied under the terms of the General Schifra License *)
(* agreement. The contents of the Schifra Reed-Solomon error correcting   *)
(* code library and all its components may not be copied or disclosed     *)
(* except in accordance with the terms of that agreement.                 *)
(*                                                                        *)
(* URL: http://www.schifra.com/license.html                               *)
(*                                                                        *)
(**************************************************************************)
*/


#ifndef INCLUDE_SCHIFRA_ERROR_PROCESSES_HPP
#define INCLUDE_SCHIFRA_ERROR_PROCESSES_HPP


#include <iostream>
#include <vector>

#include "schifra_reed_solomon_block.hpp"
#include "schifra_fileio.hpp"

namespace schifra
{

   template<std::size_t code_length, std::size_t fec_length>
   inline void add_erasure_error(const std::size_t& position, reed_solomon::block<code_length,fec_length>& block)
   {
      block[position] = (~block[position]) & 0xFF; // Or one can simply equate to zero
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void add_error(const std::size_t& position, reed_solomon::block<code_length,fec_length>& block)
   {
      block[position] = (~block[position]) & 0xFF;
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void add_error_4bit_symbol(const std::size_t& position, reed_solomon::block<code_length,fec_length>& block)
   {
      block[position] = (~block[position]) & 0x0F;
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_errors00(reed_solomon::block<code_length,fec_length>& rsblock,
                                           const std::size_t& start_position,
                                           const std::size_t& scale = 1)
   {
      for(std::size_t i = 0; i < (fec_length >> 1); ++i)
      {
         add_error((start_position + scale * i) % code_length,rsblock);
      }
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_errors_wth_mask(reed_solomon::block<code_length,fec_length>& rsblock,
                                                   const std::size_t& start_position,
                                                   const int& mask,
                                                   const std::size_t& scale = 1)
   {
      for(std::size_t i = 0; i < (fec_length >> 1); ++i)
      {
         std::size_t position = (start_position + scale * i) % code_length;
         rsblock[position] = (~rsblock[position]) & mask;

      }
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_errors(schifra::reed_solomon::block<code_length,fec_length>& rsblock,
                                          const std::size_t error_count,
                                          const std::size_t& start_position,
                                          const std::size_t& scale = 1)
   {
      for(std::size_t i = 0; i < error_count; ++i)
      {
         add_error((start_position + scale * i) % code_length,rsblock);
      }
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_erasures00(reed_solomon::block<code_length,fec_length>& rsblock,
                                              reed_solomon::erasure_locations_t& erasure_list,
                                              const std::size_t& start_position,
                                              const std::size_t& scale = 1)
   {
      std::size_t erasures[code_length];
      for(std::size_t i = 0; i < code_length; ++i) erasures[i] = 0;

      for(std::size_t i = 0; i < fec_length; ++i)
      {
         std::size_t error_position = (start_position + scale * i) % code_length;
         add_erasure_error(error_position,rsblock);
         erasures[error_position] = 1;
      }

      for(std::size_t i = 0; i < code_length; ++i)
      {
         if (erasures[i] == 1) erasure_list.push_back(i);
      }
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_erasures(reed_solomon::block<code_length,fec_length>& rsblock,
                                            reed_solomon::erasure_locations_t& erasure_list,
                                            const std::size_t erasure_count,
                                            const std::size_t& start_position,
                                            const std::size_t& scale = 1)
   {
      std::size_t erasures[code_length];
      for(std::size_t i = 0; i < code_length; ++i) erasures[i] = 0;

      for(std::size_t i = 0; i < erasure_count; ++i)
      {
         /* Note: Must make sure duplicate erasures are not added */
         std::size_t error_position = (start_position + scale * i) % code_length;
         add_erasure_error(error_position,rsblock);
         erasures[error_position] = 1;
      }

      for(std::size_t i = 0; i < code_length; ++i)
      {
         if (erasures[i] == 1) erasure_list.push_back(i);
      }
   }

   enum error_mode {
                     ERRORS_ERASURES, // Errors first then erasures
                     ERASURES_ERRORS  // Erasures first then errors
                   };

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_errors_erasures(reed_solomon::block<code_length,fec_length>& rsblock,
                                               const error_mode& mode,
                                               const std::size_t& start_position,
                                               const std::size_t& erasure_count,
                                               reed_solomon::erasure_locations_t& erasure_list,
                                               const std::size_t between_space = 0)
   {
      std::size_t error_count = (fec_length - erasure_count) >> 1;

      if ((2 * error_count) + erasure_count > fec_length)
      {
         std::cout << "corrupt_message_errors_erasures() - ERROR Too many erasures and errors!" << std::endl;
         std::cout << "Error Count:   " << error_count << std::endl;
         std::cout << "Erasure Count: " << error_count << std::endl;
         return;
      }

      std::size_t erasures[code_length];
      for(std::size_t i = 0; i < code_length; ++i) erasures[i] = 0;

      std::size_t error_position = 0;
      switch (mode)
      {
         case ERASURES_ERRORS : {
                                   for(std::size_t i = 0; i < erasure_count; ++i)
                                   {
                                      error_position = (start_position + i) % code_length;
                                      add_erasure_error(error_position,rsblock);
                                      erasures[error_position] = 1;
                                   }

                                   for(std::size_t i = 0; i < error_count; ++i)
                                   {
                                      error_position = (start_position + erasure_count + between_space + i) % code_length;
                                      add_error(error_position,rsblock);
                                   }
                                }
                                break;

         case ERRORS_ERASURES : {
                                   for(std::size_t i = 0; i < error_count; ++i)
                                   {
                                      error_position = (start_position + i) % code_length;
                                      add_error(error_position,rsblock);
                                   }

                                   for(std::size_t i = 0; i < erasure_count; ++i)
                                   {
                                      error_position = (start_position + error_count + between_space + i) % code_length;
                                      add_erasure_error(error_position,rsblock);
                                      erasures[error_position] = 1;
                                   }
                                }
                                break;
      }

      for(std::size_t i = 0; i < code_length; ++i)
      {
         if (erasures[i] == 1) erasure_list.push_back(i);
      }

   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_interleaved_errors_erasures(reed_solomon::block<code_length,fec_length>& rsblock,
                                                           const std::size_t& start_position,
                                                           const std::size_t& erasure_count,
                                                           reed_solomon::erasure_locations_t& erasure_list)
   {
      std::size_t error_count = (fec_length - erasure_count) >> 1;

      if ((2 * error_count) + erasure_count > fec_length)
      {
         std::cout << "corrupt_message_interleaved_errors_erasures() - [1] ERROR Too many erasures and errors!" << std::endl;
         std::cout << "Error Count:   " << error_count << std::endl;
         std::cout << "Erasure Count: " << error_count << std::endl;
         return;
      }

      std::size_t erasures[code_length];
      for(std::size_t i = 0; i < code_length; ++i) erasures[i] = 0;

      std::size_t error_position = 0;
      std::size_t e = 0;
      std::size_t s = 0;
      std::size_t i = 0;

      while((e < error_count) || (s < erasure_count) || (i < (error_count + erasure_count)))
      {
        error_position = (start_position + i) % code_length;
        if (((i & 0x01) == 0) && (s < erasure_count))
        {
           add_erasure_error(error_position,rsblock);
           erasures[error_position] = 1;
           s++;
        }
        else if (((i & 0x01) == 1) && (e < error_count))
        {
           e++;
           add_error(error_position,rsblock);
        }
        i++;
      }

      for(std::size_t i = 0; i < code_length; ++i)
      {
         if (erasures[i] == 1) erasure_list.push_back(i);
      }

      if ((2 * e) + erasure_list.size() > fec_length)
      {
         std::cout << "corrupt_message_interleaved_errors_erasures() - [2] ERROR Too many erasures and errors!" << std::endl;
         std::cout << "Error Count:   " << error_count << std::endl;
         std::cout << "Erasure Count: " << error_count << std::endl;
         return;
      }

   }

   template<std::size_t code_length, std::size_t fec_length>
   inline void corrupt_message_all_errors_segmented(reed_solomon::block<code_length,fec_length>& rsblock,
                                                    const std::size_t& start_position,
                                                    const std::size_t& distance_between_blocks = 1)
   {
      std::size_t block_1_error_count = (fec_length >> 2);
      std::size_t block_2_error_count = (fec_length >> 1) - block_1_error_count;

      for(std::size_t i = 0; i < block_1_error_count; ++i)
      {
         add_error((start_position + i) % code_length,rsblock);
      }

      std::size_t new_start_position = (start_position + (block_1_error_count)) + distance_between_blocks;

      for(std::size_t i = 0; i < block_2_error_count; ++i)
      {
         add_error((new_start_position + i) % code_length,rsblock);
      }
   }

   inline bool check_for_duplicate_erasures(const std::vector<int>& erasure_list)
   {
      for(std::size_t i = 0; i < erasure_list.size(); ++i)
      {
         for(std::size_t j = i + 1; j < erasure_list.size(); ++j)
         {
            if (erasure_list[i] == erasure_list[j])
            {
               return false;
            }
         }
      }
      return true;
   }

   inline void dump_erasure_list(const schifra::reed_solomon::erasure_locations_t& erasure_list)
   {
      for(std::size_t i = 0; i < erasure_list.size(); ++i)
      {
         std::cout << "[" << i << "," << erasure_list[i] << "] ";
      }
      std::cout << std::endl;
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline bool is_block_equivelent(const reed_solomon::block<code_length,fec_length>& rsblock,
                                   const std::string& data,
                                   const bool display = false)
   {
      std::string::const_iterator it = data.begin();
      for(std::size_t i = 0; i < code_length - fec_length; ++i, ++it)
      {
         if(static_cast<char>(rsblock.data[i] & 0xFF) != (*it))
         {
            if (display)
            {
               std::cout << "is_block_equivelent() - Error at loc : " << i <<
                            " d1: " << rsblock.data[i] <<
                           "\td2: " << static_cast<unsigned char>(*it) << std::endl;
            }
            return false;
         }
      }
      return true;
   }

   template<std::size_t code_length, std::size_t fec_length>
   inline bool are_blocks_equivelent(const reed_solomon::block<code_length,fec_length>& block1,
                                     const reed_solomon::block<code_length,fec_length>& block2,
                                     const std::size_t span = code_length)
   {
      for(std::size_t i = 0; i < span; ++i)
      {
         if (block1[i] != block2[i])
         {
            return false;
         }
      }
      return true;
   }

   template<std::size_t code_length, std::size_t fec_length, std::size_t stack_size>
   inline bool block_stacks_equivelent(const reed_solomon::block<code_length,fec_length> block_stack1[stack_size],
                                       const reed_solomon::block<code_length,fec_length> block_stack2[stack_size])
   {
      for(std::size_t i = 0; i < stack_size; ++i)
      {
         if (!are_blocks_equivelent(block_stack1[i],block_stack2[i]))
         {
            return false;
         }
      }
      return true;
   }

   template<std::size_t block_length, std::size_t stack_size>
   inline bool block_stacks_equivelent(const reed_solomon::data_block<std::size_t,block_length> block_stack1[stack_size],
                                       const reed_solomon::data_block<std::size_t,block_length> block_stack2[stack_size])
   {
      for(std::size_t i = 0; i < stack_size; ++i)
      {
         for(std::size_t j = 0; j < block_length; ++j)
         {
            if (block_stack1[i][j] != block_stack2[i][j])
            {
               return false;
            }
         }
      }
      return true;
   }

   inline void corrupt_file_with_burst_errors(const std::string& file_name,
                                              const long& start_position,
                                              const long& burst_length)
   {
      if (!schifra::fileio::file_exists(file_name))
      {
         std::cout << "corrupt_file() - Error: " << file_name << " does not exist!" << std::endl;
         return;
      }

      if (static_cast<std::size_t>(start_position + burst_length) >= schifra::fileio::file_size(file_name))
      {
         std::cout << "corrupt_file() - Error: Burst error out of bounds." << std::endl;
         return;
      }

      char* data = new char[burst_length];

      std::ifstream ifile(file_name.c_str(), std::ios::in | std::ios::binary);
      if (!ifile) { delete[] data; return; }
      ifile.seekg(start_position,std::ios_base::beg);
      ifile.read(&data[0],burst_length);
      ifile.close();

      for(long i = 0; i < burst_length; ++i) data[i] = ~data[i];

      std::ofstream ofile(file_name.c_str(), std::ios::in | std::ios::out | std::ios::binary);
      if (!ofile) { delete[] data; return; }
      ofile.seekp(start_position,std::ios_base::beg);
      ofile.write(&data[0],burst_length);
      ofile.close();

      delete[] data;
   }

} // namespace schifra

#endif
